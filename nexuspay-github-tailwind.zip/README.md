# NexusPay — GitHub Pages (Vite + React + Tailwind)

This project is a GitHub Pages–ready static site built with Vite, React, Tailwind CSS, and Framer Motion.
It was generated from your uploaded project and includes the uploaded PDF as a public asset at:

`/swarm.pdf` -> (source path used during generation) `/mnt/data/swarm.pdf`

## Local dev

1. Copy `.env.example` to `.env` and fill values (see below).
2. `npm install`
3. `npm run dev`

## Build and deploy to GitHub Pages

1. Ensure `homepage` or repo settings for Pages are configured.
2. `npm run deploy` will build and push `dist/` to the `gh-pages` branch using `gh-pages` package.

## Environment variables (VITE-style)

- VITE_FIREBASE_API_KEY
- VITE_FIREBASE_AUTH_DOMAIN
- VITE_FIREBASE_PROJECT_ID
- VITE_FIREBASE_STORAGE_BUCKET
- VITE_FIREBASE_MESSAGING_SENDER_ID
- VITE_FIREBASE_APP_ID
- VITE_APP_ID (optional)
- VITE_GEMINI_API_KEY (server-only — do not expose)

Note: The app uses a server-side API proxy at `/api/ai` in your original Next.js scaffold.
For static GitHub Pages, you must provide a separate serverless endpoint (e.g., Cloud Function) to call the LLM securely.
